﻿using UnityEngine;
using System.Collections;

public class CameraMovement : MonoBehaviour {
	
	public Transform sperm;
	public float smoothing;
	public float cameraDrop;
	Vector2 velocity = Vector2.zero;
	Vector3 pos;

	void Update (){
		CameraZoom();
	}

	void CameraZoom(){
		pos = Vector2.SmoothDamp(transform.position,sperm.transform.position, ref velocity, smoothing);
		transform.position = new Vector3(transform.position.x,pos.y,transform.position.z);

		if(camera.orthographicSize >= 4.65f){
			camera.orthographicSize -= 0.1f*Time.deltaTime * cameraDrop;
			if(camera.orthographicSize <= 4.65f){
				camera.orthographicSize = 4.65f;
				if(smoothing >0.5f){
					Debug.Log("gaga");
				smoothing -=1f* Time.deltaTime;
				}
			}
		}
	}
}
