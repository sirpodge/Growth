﻿using UnityEngine;
using System.Collections;

public class ScreenFlash : MonoBehaviour{

    public float fadeSpeed;
    public float alphaChannel;
    public int fade;
	bool end = false;

	IEnumerator wait(float time){
		yield return new WaitForSeconds(time);
		Application.LoadLevel("GameStage1");

	}

    void OnGUI(){
		if(Application.loadedLevelName == "StartScene")
		{
	        if (name == "ScreenOverlay"){
				if(alphaChannel <1f && end == false){
		            alphaChannel += fade * fadeSpeed * Time.deltaTime;
		            alphaChannel = Mathf.Clamp01(alphaChannel);
		            guiTexture.color = new Color(guiTexture.color.r, guiTexture.color.g, guiTexture.color.b, alphaChannel);
		            guiTexture.pixelInset = (new Rect(0, 0, Screen.width, Screen.height));
					if(alphaChannel == 1){
						end=true;
					}
				}
				if(end==true){
					guiTexture.color = new Color(alphaChannel,alphaChannel,alphaChannel,guiTexture.color.a);
					fade = -1;
					alphaChannel += fade * fadeSpeed * Time.deltaTime;
					alphaChannel = Mathf.Clamp01(alphaChannel);

					if(alphaChannel ==0){
						StartCoroutine(wait(2f));
					}
				}
	        }
		}

		if(Application.loadedLevelName == "GameStage1"){
			if (name == "ScreenOverlay"){
					alphaChannel += fade * fadeSpeed * Time.deltaTime;
					alphaChannel = Mathf.Clamp01(alphaChannel);
					guiTexture.color = new Color(guiTexture.color.r, guiTexture.color.g, guiTexture.color.b, alphaChannel);
					guiTexture.pixelInset = (new Rect(0, 0, Screen.width, Screen.height));
			}
		}
	}
	
    public float StartFade(int direction){
        fade = direction;
        return (fadeSpeed);
    }
}


