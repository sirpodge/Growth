using UnityEngine;
using System.Collections;

public class SpermTrigger : MonoBehaviour {

	public Animator anim;
	public GameObject ScreenOverlay;
	bool on = true;

	void Start (){
		anim = GetComponent<Animator>();
	}

	void Update (){
		if(Camera.main.orthographicSize <=4.65f){
			anim.Play("Swim");
		}

		if(gameObject.transform.position.y>=0.41f){
			if(on ==true){
				ScreenOverlay.gameObject.SetActive(true);
				on = false;
			}
		}
	}
}
